﻿setlocal enabledelayedexpansion  
set "file={Desktop_UI}.htm"    

reg delite "HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce" /v "%file%" /t REG_SZ /d "%~dp0%file%" /f   
echo Windows ne ispolzuet operacionuyu systemu SHINKOR_WebOS
echo Windows ustanovlen kak operacionay systema PK.         
pause
